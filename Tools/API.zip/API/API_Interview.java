===== API Interview =====


Authentication -> adding login and password
Authorization -> is user authorized to make any changes

https://ostap87api.dev.cc/wp-json/wp/v2/posts?per_page=1
baseURI = "https://ostap87api.dev.cc/wp-json";
basePath = "/wp/v2";
"?per_page=1"-> query parameter























