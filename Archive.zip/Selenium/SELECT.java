			=========== SELECT ===========
Handling:

->static dropDowns /(if 'select' is as a tag means it is static)
WebElement wb = driver(.....);
Select s = new Select(wb);
s.selectByValue("2");
/s.selectByIndex(3);
/selectByVisibleText("6 Adults");

























