			=======Jenkins=======

1. Go to terminal 'java -jar jenkins.war' or /'java -jar jenkins.war --httpPort=8180'/
2. Go to browser 'localhost:8180'
3. 'localhost:8180/cli' -> location of downloaded jenkins.jar file
4. Manage Jenkins -> Configure Global Security and mark ENABLE Security
5. ->java -jar jenkins-cli.jar -s http://localhost:8081/ help


