		================== PAGE OBJECT MODEL ====================
							 Design Patern

Creating the Java classes that represents each page on the application



SuitCRM project:

-> pages
	-loginPage.java
	-homePage.java
	-accountCreationPAge.java

*inside the page classes we will be store WebElements and methods related to that specific page.



























