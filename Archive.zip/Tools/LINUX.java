					======= LINUX =======
Commands:
ls -> show all of the major directories filed under a given file system
cd -> allow the user to change between file directories
mv -> move - allows a user to move a file to another folder or directory
mkdir -> allows the user to make a new directory
touch -> makes empty file = 'touch testfile.txt'
rmdir -> remove directory
rm -> remove file only
locate -> means to find a file
clear -> command clears the screen and wipes the board clean
.. -> up directory
pwd -> show current location

			+++++ MAVEN +++++
mvn --version -> version of maven3.5.3
mvn clean -> clean directory
mvn compile -> compile sorce code
mvn test -> run html report
mvn verify -> run json report
mvn verify -Doption tag=tagName




























